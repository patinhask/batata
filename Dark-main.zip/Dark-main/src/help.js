const help = (prefix) => {
    return `

➸ Prefix:  「${prefix} 」
➸ Status: 「 Online 」

Figurinhas      
Comando : ${prefix}sticker ou ${prefix}stiker
Comando : ${prefix}sticker nobg ou ${prefix}stiker nobg
converter imagem em adesivo removendo o fundo

Comando : ${prefix}toimg
converter adesivo em imagem

Comando : ${prefix}tsticker ou ${prefix}tstiker
converter texto em adesivo

meme
Comando : ${prefix}meme
Comando : ${prefix}memeindo

outros      
Comando : ${prefix}gtts
converter texto em fala/áudio

Comando : ${prefix}loli
Comando : ${prefix}nsfwloli
Comando : ${prefix}url2img
Comando : ${prefix}simi

Comando : ${prefix}wait
pesquisar sobre o anime por imagem

Comando : ${prefix}setprefix
util em : alterar o prefixo do bot
uso : ${prefix}setprefix [texto|opcional]\nexemplo : ${prefix}setprefix ?

Comandos do administrador     
➸ Comando : ${prefix}linkgroup
➸ Comando : ${prefix}marcar
➸ Comando : ${prefix}simih ativar o modo simi no grupo
➸ uso : ${prefix}simih 1 para ativar o modo simi e ${prefix}simih 0 para desativar o modo simih
➸ Comando : ${prefix}add
➸ Comando : ${prefix}kick
➸ Comando : ${prefix}promote
➸ Comando : ${prefix}demote

➸ uso : ${prefix}demote e o @da pessoa\n
➸ Nota : Você precisa ser admin e o bot também

➸ ${prefix}help1 ♔